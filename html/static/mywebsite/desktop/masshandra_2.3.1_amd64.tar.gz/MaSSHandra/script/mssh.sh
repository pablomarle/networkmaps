#!/bin/bash
if [ "$#" -ne 2 ] 
then
	echo "Hostname Required"
else
	read -p "Username: " username
	echo "Connecting to $1 on port $2 ..."
	ssh $username@$1 -p $2
fi
sleep 3
